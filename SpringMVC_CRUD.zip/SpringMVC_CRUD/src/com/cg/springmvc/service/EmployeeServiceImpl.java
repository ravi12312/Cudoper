package com.cg.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.springmvc.dao.IEmployeeDao;
import com.cg.springmvc.dto.Employee;

@Service("employeeservice")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {
	
	@Autowired
	IEmployeeDao dao;
	
	@Override
	public int addEmployeeData(Employee emp) {
		return dao.addEmployeeData(emp);
	}

	@Override
	public List<Employee> showAllEmployee() {
		return dao.showAllEmployee();
	}

	@Override
	public void deleteEmployee(int empId) {

		dao.deleteEmployee(empId);
	}

	@Override
	public void updateEmployee(Employee emp) {

		dao.updateEmployee(emp);
	}

	@Override
	public Employee searchEmployee(int id) {
		return dao.searchEmployee(id);
	}

}
